# EduConnect - Online Learning Platform

## Project Description
This is a comprehensive web development project for CSE211 Web Programming, creating an online learning platform called "EduConnect" using semantic HTML5, advanced form handling, and accessibility best practices.

## Project Structure
```
webassignment/
├── index.html (Homepage)
├── pages/
│   ├── about.html (About Us page)
│   ├── contact.html (Contact Me page)
│   ├── registration.html (Registration form)
│   ├── course-catalog.html (Course listings)
│   ├── course-detail.html (Detailed course information)
│   ├── student-dashboard.html (Student dashboard)
│   ├── calculator.html (Scientific calculator)
│   ├── calculator-result.html (Calculator results)
│   └── thank.html (Registration success page)
└── README.txt (This file)
```

## Features Implemented
- Semantic HTML5 structure with proper element usage
- Comprehensive registration form with advanced validation
- Course catalog with filtering capabilities
- Student dashboard with progress tracking
- Scientific calculator with memory functions
- Responsive design principles (HTML structure only)
- Accessibility features (ARIA labels, proper form structure)
- Cross-page navigation system

## AI Tools Usage

### Which AI Tools Were Used
- **Claude AI (Anthropic)** - Primary AI assistant for web development guidance
- **Cursor IDE AI Features** - Code completion and syntax suggestions

### How AI Tools Were Used

#### HTML Structure and Semantics
- **Asked Claude to explain semantic HTML5 elements**: Learned the proper usage of header, nav, main, section, article, aside, and footer elements
- **Used Claude to understand form validation attributes**: Gained knowledge about required, pattern, minlength, maxlength, min, max, step attributes
- **Requested guidance on accessibility best practices**: Learned about ARIA attributes, proper labeling, and keyboard navigation

#### Form Development
- **Asked Claude about advanced form controls**: Understanding fieldset, legend, and complex input types
- **Used Claude to learn about form validation**: HTML5 validation attributes and JavaScript integration
- **Requested help with form accessibility**: ARIA roles, describedby attributes, and screen reader compatibility

#### JavaScript Functionality
- **Asked Claude to explain DOM manipulation**: Learning about event handlers and dynamic content updates
- **Used Claude to understand URL parameter parsing**: For calculator result page functionality
- **Requested guidance on form data handling**: Processing and displaying user input

#### Code Organization
- **Asked Claude about HTML commenting standards**: Learning proper documentation practices
- **Used Claude to understand code structure**: Organizing complex nested elements
- **Requested help with debugging syntax errors**: Understanding HTML validation issues

### What Was Learned from Using These Tools

#### Technical Knowledge Gained
1. **Semantic HTML5 Structure**: Understanding the purpose and proper usage of each semantic element
2. **Form Validation**: Learning HTML5 validation attributes and their browser support
3. **Accessibility Standards**: Understanding WCAG guidelines and ARIA implementation
4. **JavaScript Integration**: Learning how to enhance HTML forms with interactive functionality
5. **Code Organization**: Best practices for commenting, indentation, and file structure

#### Problem-Solving Skills Developed
1. **Debugging HTML Validation Errors**: Learning to identify and fix common HTML issues
2. **Cross-Browser Compatibility**: Understanding different browser implementations of HTML5 features
3. **User Experience Design**: Creating intuitive navigation and form interactions
4. **Performance Considerations**: Writing clean, efficient HTML code

#### Best Practices Learned
1. **Progressive Enhancement**: Building functionality that works without JavaScript
2. **Accessibility-First Design**: Ensuring all users can access and use the website
3. **Semantic Markup**: Using HTML elements for their intended purpose
4. **Form Usability**: Creating user-friendly forms with proper validation and feedback

### Confirmation of Understanding
I understand and can explain every line of code in this project, including:

- **HTML5 semantic elements**: Why each element was chosen and how they contribute to document structure
- **Form validation attributes**: How each validation rule works and why it was implemented
- **ARIA attributes**: How they improve accessibility and screen reader compatibility
- **JavaScript functionality**: How the calculator works and processes user input
- **CSS integration points**: Where styling hooks are placed for future enhancement
- **Navigation structure**: How the site architecture supports user experience

The AI tools served as educational resources to understand web development concepts, but all code was written and tested by me. I can demonstrate the functionality of any feature and explain the reasoning behind implementation decisions.

## Browser Compatibility
This project uses standard HTML5 elements and should work in all modern browsers including:
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## Validation
All HTML files have been validated for:
- Proper nesting and syntax
- Semantic element usage
- Accessibility compliance
- Form validation attributes

## Future Enhancements
- CSS styling for visual design
- JavaScript enhancements for interactivity
- Server-side form processing
- Database integration for user management
- Mobile-responsive layouts

---
**Student Declaration**: This project was completed with AI assistance for learning purposes. All code has been written, tested, and understood by the student. The student can explain and defend every implementation decision and line of code.
